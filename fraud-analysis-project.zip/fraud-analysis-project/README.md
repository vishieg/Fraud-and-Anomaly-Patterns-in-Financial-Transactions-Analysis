# Comparative Analysis of Fraud & Anomaly Patterns in Financial Transactions

A comprehensive data analysis and machine learning project analyzing RBI (Reserve Bank of India) fraud data across multiple financial institutions to detect anomalous patterns in financial transactions using unsupervised learning techniques.

## 📊 Project Overview

This project integrates RBI fraud data spanning 2020-2026 across 15+ Indian banks with digital payments (UPI) transaction data to:
- Identify correlations between transaction volumes and fraud patterns
- Detect anomalies using multiple unsupervised machine learning algorithms
- Analyze fraud trends, recovery patterns, and financial insights
- Compare the effectiveness of different anomaly detection approaches

## 📈 Dataset

**RBI Fraud Data:**
- Time Period: 2020-2026
- Banks Covered: 15+ Indian financial institutions
- Features: 17 hierarchical columns including fraud counts, financial loss, recovery amounts
- Source: Reserve Bank of India

**Digital Payments Data:**
- Time Period: June 2020 - April 2026 (monthly granularity)
- Transaction Type: UPI (Unified Payments Interface) volumes
- Metrics: Daily and aggregated yearly payment transactions

## 🛠️ Technologies & Tools

- **Languages:** Python
- **Data Processing:** Pandas, NumPy
- **Machine Learning:** Scikit-learn, TensorFlow/Keras
- **Visualization:** Matplotlib, Seaborn
- **Environment:** Jupyter Notebook

## 📁 Project Structure

```
fraud-analysis-project/
├── README.md
├── requirements.txt
├── notebooks/
│   └── Comparative_Analysis_Fraud_Anomaly_Detection.ipynb
├── data/
│   ├── rbi_fraud_data.xlsx
│   └── digital_payments.xlsx
├── src/
│   ├── data_processing.py
│   ├── eda.py
│   └── anomaly_detection.py
└── results/
    └── visualizations/
```

## 🔑 Key Features

### 1. Data Integration & Cleaning
- Multi-level indexed hierarchical data transformation
- Pandas melt operations for time-series restructuring
- Missing value handling and column standardization
- Integration of two disparate data sources

### 2. Exploratory Data Analysis (EDA)
- 15+ visualizations including:
  - Time-series trend analysis
  - Correlation heatmaps
  - Scatter plots for multi-dimensional relationships
  - Distribution analysis

### 3. Anomaly Detection - Isolation Forest
- Unsupervised learning approach
- 5% contamination threshold
- Effective for high-dimensional financial data
- Identifies outliers deviating from normal banking behavior

### 4. Anomaly Detection - Autoencoder (Deep Learning)
- Neural network-based approach using TensorFlow/Keras
- Architecture: 3-neuron bottleneck layer
- Training: 50 epochs with 20% validation split
- Threshold: 95th percentile reconstruction error

### 5. Comparative Analysis
- Evaluation of both algorithms
- Identification of complementary strengths
- Performance metrics on multi-dimensional data
- Insight generation for model selection

## 📊 Key Insights

- Successfully identified anomalous patterns in financial fraud data
- Revealed relationships between UPI transaction growth and fraud trends
- Demonstrated complementary strengths of statistical vs. deep learning approaches
- Generated actionable insights on fraud risks across Indian banking sector

## 🚀 Quick Start

### Prerequisites
```bash
Python 3.8+
pip
```

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/fraud-analysis-project.git
cd fraud-analysis-project
```

2. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies
```bash
pip install -r requirements.txt
```

### Running the Analysis

Open and run the Jupyter notebook:
```bash
jupyter notebook notebooks/Comparative_Analysis_Fraud_Anomaly_Detection.ipynb
```

## 📈 Results

### Isolation Forest Results
- Identifies point anomalies effectively
- Fast computation on large datasets
- Suitable for real-time fraud detection

### Autoencoder Results
- Captures complex non-linear patterns
- Better for detecting collective anomalies
- Requires more computational resources

## 🔍 Methodology

1. **Data Loading & Exploration:** Load RBI fraud and digital payments data
2. **Data Transformation:** Reshape hierarchical data into time-series format
3. **Feature Engineering:** Create derived metrics (fraud rates, etc.)
4. **Normalization:** Standardize features for ML models
5. **Model Training:** Train both Isolation Forest and Autoencoder
6. **Evaluation:** Compare detection results and performance
7. **Visualization:** Generate insights through comprehensive plots

## 📊 Visualizations Generated

- Total frauds over time
- Financial loss trends
- Recovery rate analysis
- UPI transaction growth
- Loss vs. Recovery comparison
- Anomaly detection results overlay
- Correlation heatmaps

## 🤝 Contributing

Contributions are welcome! Please feel free to submit issues or pull requests.

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 📧 Contact

For questions or collaboration, please reach out or open an issue in the repository.

## 📚 References

- Reserve Bank of India - Payment Systems Data
- Isolation Forest: Liu et al. (2008)
- Autoencoders for Anomaly Detection: Sakurada & Yairi (2014)

---

**Last Updated:** May 2026
